function generateBio(){
let name=document.getElementById('name').value;
let profession=document.getElementById('profession').value;
let skills=document.getElementById('skills').value;
let hobbies=document.getElementById('hobbies').value;
let goal=document.getElementById('goal').value;
let platform=document.getElementById('platform').value;
let tone=document.getElementById('tone').value;
document.getElementById('bioOutput').value=`Hi, I'm ${name}, a ${profession}. I specialize in ${skills} and enjoy ${hobbies}. My goal is to ${goal}. This ${tone.toLowerCase()} bio is designed for ${platform}.`;
}
function copyBio(){navigator.clipboard.writeText(document.getElementById('bioOutput').value);alert('Bio copied successfully!');}